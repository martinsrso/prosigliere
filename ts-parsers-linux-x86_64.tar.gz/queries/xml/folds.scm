[
  (element)
  (doctypedecl)
  (Comment)
] @fold
