(braced_word) @fold
