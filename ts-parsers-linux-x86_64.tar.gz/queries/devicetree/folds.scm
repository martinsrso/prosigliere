(node) @fold
