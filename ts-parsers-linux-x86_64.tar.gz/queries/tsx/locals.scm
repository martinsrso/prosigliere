; inherits: typescript
