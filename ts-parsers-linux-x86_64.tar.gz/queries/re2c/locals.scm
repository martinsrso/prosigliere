(body) @local.scope
