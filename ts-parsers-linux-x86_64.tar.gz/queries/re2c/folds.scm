[
  (body)
  (action)
] @fold
