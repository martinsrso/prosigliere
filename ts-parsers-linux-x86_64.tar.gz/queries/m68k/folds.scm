(element_list) @fold
