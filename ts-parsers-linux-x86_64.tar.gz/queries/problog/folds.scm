; inherits: prolog
