[
  (object)
  (array)
] @local.scope
