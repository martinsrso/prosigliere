[
  (pair)
  (object)
  (array)
] @fold
