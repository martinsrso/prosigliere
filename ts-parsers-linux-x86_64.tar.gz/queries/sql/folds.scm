(statement) @fold
