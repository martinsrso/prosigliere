(xact) @fold
